import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss
from datetime import date

st.set_page_config(page_title="StockMind AI", page_icon="📈", layout="wide")
st.title("📈 StockMind AI")
st.caption("Indian equities research prototype · educational use · not a live advisory service")

with st.sidebar:
    st.header("Analysis settings")
    ticker = st.text_input("Yahoo Finance ticker", value="RELIANCE.NS", help="Examples: RELIANCE.NS, TCS.NS, BEL.NS, ^NSEI")
    horizon_label = st.selectbox("Prediction horizon", ["1 trading day", "5 trading days", "20 trading days"])
    horizon = {"1 trading day": 1, "5 trading days": 5, "20 trading days": 20}[horizon_label]
    period = st.selectbox("Historical data", ["2y", "5y", "10y"], index=1)
    st.caption("Data is supplied by Yahoo Finance and may be delayed, incomplete, or subject to provider terms.")

@st.cache_data(ttl=900)
def load_data(symbol, period):
    df = yf.download(symbol, period=period, interval="1d", auto_adjust=True, progress=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.rename(columns=str.title)
    needed = ["Open", "High", "Low", "Close", "Volume"]
    return df[needed].dropna()

def rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    down = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = up / down.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def make_features(df):
    x = pd.DataFrame(index=df.index)
    close, high, low, volume = df["Close"], df["High"], df["Low"], df["Volume"]
    x["ret_1"] = close.pct_change()
    x["ret_5"] = close.pct_change(5)
    x["ret_20"] = close.pct_change(20)
    x["volatility_10"] = x["ret_1"].rolling(10).std()
    x["volatility_20"] = x["ret_1"].rolling(20).std()
    x["rsi_14"] = rsi(close)
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    x["macd_rel"] = macd / close
    x["macd_signal_rel"] = (macd - macd.ewm(span=9, adjust=False).mean()) / close
    x["sma20_gap"] = close / close.rolling(20).mean() - 1
    x["sma50_gap"] = close / close.rolling(50).mean() - 1
    x["sma200_gap"] = close / close.rolling(200).mean() - 1
    x["volume_ratio"] = volume / volume.rolling(20).mean()
    x["range_pct"] = (high - low) / close
    return x.replace([np.inf, -np.inf], np.nan)

try:
    raw = load_data(ticker.strip().upper(), period)
    if raw.empty or len(raw) < 260:
        st.error("Not enough daily price history returned for this ticker. Try a different ticker or longer history.")
        st.stop()
except Exception as e:
    st.error(f"Could not load data for this symbol. Check the ticker and internet/data provider access. Details: {e}")
    st.stop()

features = make_features(raw)
# Define target precisely: adjusted close after H sessions greater than today's adjusted close.
target = (raw["Close"].shift(-horizon) > raw["Close"]).astype(int).rename("up")
dataset = features.join(target).dropna()
# Exclude final horizon rows where future target is unavailable.
if len(dataset) <= 100:
    st.error("Not enough usable rows to train a model.")
    st.stop()
dataset = dataset.iloc[:-horizon]
feature_cols = list(features.columns)
split = int(len(dataset) * 0.8)
train, test = dataset.iloc[:split], dataset.iloc[split:]
if len(test) < 20 or train["up"].nunique() < 2:
    st.error("Insufficient class/history diversity for a useful evaluation.")
    st.stop()

model = Pipeline([
    ("scale", StandardScaler()),
    ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced"))
])
model.fit(train[feature_cols], train["up"])
test_prob = model.predict_proba(test[feature_cols])[:, 1]
test_pred = (test_prob >= 0.5).astype(int)
latest = features.dropna().iloc[[-1]]
prob_up = float(model.predict_proba(latest[feature_cols])[:, 1][0])
prob_down = 1 - prob_up
latest_close = float(raw["Close"].iloc[-1])
latest_date = raw.index[-1].date()
rsi_now = float(rsi(raw["Close"]).dropna().iloc[-1])
sma20 = float(raw["Close"].rolling(20).mean().iloc[-1])
sma50 = float(raw["Close"].rolling(50).mean().iloc[-1])
sma200 = float(raw["Close"].rolling(200).mean().iloc[-1])
macd = raw["Close"].ewm(span=12, adjust=False).mean() - raw["Close"].ewm(span=26, adjust=False).mean()
signal = macd.ewm(span=9, adjust=False).mean()
macd_state = "Bullish MACD" if macd.iloc[-1] > signal.iloc[-1] else "Bearish MACD"
trend = "Above 20/50/200-day averages" if latest_close > sma20 and latest_close > sma50 and latest_close > sma200 else "Mixed/weak trend" if latest_close < sma20 and latest_close < sma50 else "Mixed trend"

c1, c2, c3, c4 = st.columns(4)
c1.metric("Latest adjusted close", f"{latest_close:,.2f}")
c2.metric(f"Model P(up) · {horizon_label}", f"{prob_up:.1%}")
c3.metric("Test accuracy", f"{accuracy_score(test['up'], test_pred):.1%}")
c4.metric("Test Brier score", f"{brier_score_loss(test['up'], test_prob):.3f}", help="Lower is better; 0 is perfect. Evaluate alongside calibration and baselines.")
st.caption(f"Last daily bar: {latest_date}. Model is trained on earlier history and tested on the final 20% of available labeled observations. This is a simple baseline, not proof of predictive edge.")

left, right = st.columns([1.15, 1])
with left:
    st.subheader("Price history")
    chart = raw[["Close"]].copy()
    chart["SMA 20"] = raw["Close"].rolling(20).mean()
    chart["SMA 50"] = raw["Close"].rolling(50).mean()
    st.line_chart(chart.tail(180))
with right:
    st.subheader("Technical snapshot")
    st.write(f"**RSI (14):** {rsi_now:.1f} — " + ("oversold zone" if rsi_now < 30 else "overbought zone" if rsi_now > 70 else "middle range"))
    st.write(f"**MACD:** {macd_state}")
    st.write(f"**Trend:** {trend}")
    st.write(f"**20-day average:** {sma20:,.2f}")
    st.write(f"**50-day average:** {sma50:,.2f}")
    st.write(f"**200-day average:** {sma200:,.2f}")

st.subheader("How to interpret this output")
if prob_up >= 0.60:
    st.info("The baseline model currently assigns a higher-than-even probability to an up-close at the selected horizon. Check calibration, market context, liquidity, costs and downside risk before drawing conclusions.")
elif prob_up <= 0.40:
    st.warning("The baseline model currently assigns a lower-than-even probability to an up-close at the selected horizon. This is not a short recommendation.")
else:
    st.info("The baseline model does not show a strong directional probability. Consider waiting for clearer evidence rather than forcing a trade.")

st.subheader("Backtest diagnostics")
st.write(f"Training observations: {len(train):,} · Test observations: {len(test):,} · Test up-rate: {test['up'].mean():.1%}")
st.write("Important: this prototype uses a single chronological holdout, does not yet model transaction costs/slippage, and does not include fundamentals, news, survivorship-bias controls, or walk-forward calibration. It is for research prototyping only.")

with st.expander("Risk, data and compliance notes"):
    st.markdown("""
    - Probabilities are model estimates, not guarantees and not certainty scores.
    - Historical relationships can break; out-of-sample performance may deteriorate.
    - Daily data only in this first version. Intraday analysis needs a separate data source and realistic intraday testing.
    - This is not personalized financial advice or a buy/sell instruction.
    - Before offering paid research, recommendations, targets or advisory services in India, obtain qualified legal/compliance advice on applicable SEBI registration, disclosures, data licences and advertising rules.
    """)
st.caption("StockMind AI · prototype build 0.1 · no broker integration or order execution")

# StockMind AI — free prototype

## What's included
- Streamlit web dashboard for NSE symbols available through Yahoo Finance (examples: `RELIANCE.NS`, `TCS.NS`, `BEL.NS`)
- Daily price history, RSI, MACD, moving-average context
- Baseline logistic-regression probability estimate for 1, 5, or 20 trading days
- Chronological holdout evaluation with accuracy and Brier score
- Basic risk and compliance notices

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL shown by Streamlit.

## Important limitations
This is a research prototype, not a validated prediction product. It uses daily data, a simple single holdout split, and no transaction-cost model, walk-forward validation, fundamentals/news, intraday feed, authentication, database, monitoring, or production controls. Data availability and usage are subject to the data provider's terms. Do not market outputs as guaranteed returns or paid stock tips. Get Indian securities-law and data-licensing advice before a public commercial launch.
